import 'dart:math';

void main() {
  Map<String, Map<String, int>> jarak = {
    'A': {'B': 10, 'C': 15, 'D': 20, 'E': 25},
    'B': {'A': 10, 'C': 35, 'D': 25, 'E': 30},
    'C': {'A': 15, 'B': 35, 'D': 30, 'E': 20},
    'D': {'A': 20, 'B': 25, 'C': 30, 'E': 15},
    'E': {'A': 25, 'B': 30, 'C': 20, 'D': 15}
  };

  List<String> lokasi = ['A', 'B', 'C', 'D', 'E'];
  List<List<String>> semuaRute = getPermutations(lokasi);
  List<String> ruteTerpendek = [];
  int jarakTerpendek = double.infinity.toInt();

  semuaRute.forEach((rute) {
    int totalJarak = calculateTotalDistance(rute, jarak);
    if (totalJarak < jarakTerpendek) {
      jarakTerpendek = totalJarak;
      ruteTerpendek = rute;
    }
  });

  print('Rute terpendek adalah: $ruteTerpendek dengan jarak $jarakTerpendek km');
}

List<List<String>> getPermutations(List<String> list) {
  if (list.length == 1) return [list];
  return list.expand((i) => getPermutations(list.where((x) => x != i).toList()).map((perm) => [i] + perm)).toList();
}

int calculateTotalDistance(List<String> rute, Map<String, Map<String, int>> jarak) {
  return List.generate(rute.length - 1, (i) => jarak[rute[i]]![rute[i + 1]]!).reduce((value, element) => value + element);
}