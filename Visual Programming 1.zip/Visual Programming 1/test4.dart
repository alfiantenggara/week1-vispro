import 'dart:io';

void main() {
  print('Masukkan suhu dalam Celsius:');
  String? inputCelsius = stdin.readLineSync();
  if (inputCelsius != null && inputCelsius.isNotEmpty) {
    double celsius = double.tryParse(inputCelsius) ?? 0.0;
    double fahrenheit = (celsius * 9 / 5) + 32;
    print('$celsius derajat Celsius sama dengan $fahrenheit derajat Fahrenheit.');
  } else {
    print('Input tidak valid');
  }
}