void main() {
  // Tahapan pembangunan
  String tahap = "A";

  // Kondisi untuk menjalankan tahapan berikutnya
  if (tahap == "A") {
    print("Tahap 1: A selesai (Fondasi)");
    print("Tahap 2: B selesai (Struktur)");
    print("Tahap 3: D selesai (Dinding)");
    print("Tahap 4: C selesai (Atap)");
    print("Tahap 5: E selesai (Instalasi Listrik)");
    print("Tahap 6: F selesai (Finishing)");
  }
}
