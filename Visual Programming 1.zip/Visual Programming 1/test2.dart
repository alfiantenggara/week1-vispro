void main() {
  // Jumlah uang yang ditabung Sinta per hari
  const int tabunganPerHari = 5000;

  // Jumlah hari menabung
  const int jumlahHari = 30;

  // Menghitung total tabungan Sinta selama 30 hari
  int totalTabungan = tabunganPerHari * jumlahHari;

  // Output total tabungan Sinta
  print
  ('Total uang dicelengan Sinta setelah $jumlahHari hari: Rp $totalTabungan');
}