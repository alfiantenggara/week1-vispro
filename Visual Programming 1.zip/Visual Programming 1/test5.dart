import 'dart:io';

void main() {
  print('Masukkan jumlah jam parkir:');
  String? inputJam = stdin.readLineSync();
  if (inputJam != null && inputJam.isNotEmpty) {
    int jam = int.tryParse(inputJam) ?? 0;
    int biaya = hitungBiayaParkir(jam);
    print('Total biaya parkir untuk $jam jam adalah Rp $biaya');
  } else {
    print('Input tidak valid');
  }
}

int hitungBiayaParkir(int jam) {
  return jam <= 2 ? 2000 * jam : 4000 + (jam - 2) * 1000;
}
