void main() {
  // Jumlah mesin cuci di apartemen
  int jumlahMesinCuci = 3;

  // Durasi penggunaan maksimal mesin cuci per hari (dalam jam)
  int durasiMaksimalPerMesin = 2;

  // Durasi mencuci yang diinginkan oleh setiap penghuni (dalam jam)
  double durasiMencuciPerPenghuni = 1.5;

  // Menghitung total durasi mencuci yang dapat disediakan oleh semua mesin dalam satu hari
  int totalDurasiTersedia = jumlahMesinCuci * durasiMaksimalPerMesin;

  // Menghitung berapa banyak penghuni yang dapat mencuci dalam satu hari
  int jumlahPenghuniYangDapatMencuci = totalDurasiTersedia ~/ durasiMencuciPerPenghuni;

  // Menampilkan hasil
  print('Jumlah penghuni yang dapat mencuci di hari yang sama adalah: $jumlahPenghuniYangDapatMencuci orang');
}