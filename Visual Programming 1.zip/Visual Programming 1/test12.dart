void main() {
  // Jumlah unit yang diproduksi per jam
  int produksiPerJam = 20;

  // Jumlah jam operasional per hari
  int jamOperasionalPerHari = 8;

  // Jumlah hari kerja dalam satu minggu
  int hariKerja = 5;

  // Menghitung total produksi dalam satu minggu
  int totalProduksiMingguan = produksiPerJam * jamOperasionalPerHari * hariKerja;

  // Menampilkan hasil
  print('Total unit barang yang diproduksi dalam satu minggu adalah: $totalProduksiMingguan unit');
}