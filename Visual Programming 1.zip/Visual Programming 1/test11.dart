void main() {
  // Durasi penggunaan dalam menit
  int durasiChatting = 60;
  int durasiVideo = 30;
  int durasiGame = 45;

  // Konsumsi baterai per 5 menit untuk masing-masing aktivitas
  double konsumsiChatting = 1.0; // 1% per 5 menit
  double konsumsiVideo = 2.0;    // 2% per 5 menit
  double konsumsiGame = 3.0;     // 3% per 5 menit

  // Menghitung total konsumsi baterai
  double totalKonsumsiChatting = (durasiChatting / 5) * konsumsiChatting;
  double totalKonsumsiVideo = (durasiVideo / 5) * konsumsiVideo;
  double totalKonsumsiGame = (durasiGame / 5) * konsumsiGame;

  // Menghitung sisa baterai
  double sisaBaterai = 100 - (totalKonsumsiChatting + totalKonsumsiVideo + totalKonsumsiGame);

  // Menampilkan hasil
  print('Sisa baterai setelah penggunaan adalah: $sisaBaterai%');
}