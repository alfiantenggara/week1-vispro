void main() {
  List<String> nasabah = ['A', 'B', 'C', 'D', 'E'];
  int loket = 1;

  nasabah.asMap().forEach((i, nasabahName) {
    print('Nasabah $nasabahName dilayani di loket $loket');
    loket = (loket == 1) ? 2 : 1;  // Bergantian antara loket 1 dan 2
  });
}