void main() {
  List<String> tasks = ['A', 'C', 'B', 'D', 'E'];
  print('Urutan tugas yang efisien adalah:');
  tasks.forEach((task) {
    print(task);
  });
}