import 'dart:io';
import 'dart:math';

void main() {
  print('Masukkan diameter lingkaran:');
  String? inputDiameter = stdin.readLineSync();
  if (inputDiameter != null && inputDiameter.isNotEmpty) {
    double diameter = double.tryParse(inputDiameter) ?? 0.0;
    double radius = diameter / 2;
    double area = pi * radius * radius;
    print('Luas lingkaran dengan diameter $diameter adalah $area');
  } else {
    print('Input tidak valid');
  }
}