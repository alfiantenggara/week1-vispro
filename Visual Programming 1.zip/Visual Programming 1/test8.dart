void main() {
  // Konsumsi per jam dalam kWh
  double konsumsiACPerJam = 1.5;
  double konsumsiTVPerJam = 0.2;
  double konsumsiLampuPerJam = 0.1;

  // Durasi penggunaan dalam jam
  int durasiAC = 8;
  int durasiTV = 5;
  int durasiLampu = 12;

  // Menghitung total konsumsi energi
  double totalKonsumsiAC = konsumsiACPerJam * durasiAC;
  double totalKonsumsiTV = konsumsiTVPerJam * durasiTV;
  double totalKonsumsiLampu = konsumsiLampuPerJam * durasiLampu;

  double totalKonsumsiEnergi = totalKonsumsiAC + totalKonsumsiTV + totalKonsumsiLampu;

  // Menampilkan hasil
  print('Total konsumsi energi harian adalah: $totalKonsumsiEnergi kWh');
}