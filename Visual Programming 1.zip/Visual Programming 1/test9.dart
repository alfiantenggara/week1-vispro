void main() {
  int maxWeight = 10;
  List<Item> items = [
    Item(weight: 3, value: 50, name: 'Makanan'),
    Item(weight: 2, value: 30, name: 'Pakaian'),
    Item(weight: 4, value: 40, name: 'Alat masak'),
    Item(weight: 5, value: 70, name: 'Tenda'),
    Item(weight: 2, value: 20, name: 'Sleeping bag')
  ];

  List<List<int>> dp = List.generate(items.length + 1, 
    (i) => List.generate(maxWeight + 1, (j) => 0));

  items.asMap().forEach((i, item) {
    List.generate(maxWeight + 1, (w) {
      if (item.weight <= w) {
        dp[i + 1][w] = max(dp[i][w], dp[i][w - item.weight] + item.value);
      } else {
        dp[i + 1][w] = dp[i][w];
      }
    });
  });

  print('Maximum value: ${dp[items.length][maxWeight]}');
  printSelectedItems(dp, items, maxWeight);
}

void printSelectedItems(List<List<int>> dp, List<Item> items, int maxWeight) {
  int i = items.length;
  int w = maxWeight;
  print('Items to take:');
  while (i > 0) {
    if (dp[i][w] != dp[i - 1][w]) {
      print('${items[i - 1].name}');
      w -= items[i - 1].weight;
    }
    i--;
  }
}

class Item {
  int weight;
  int value;
  String name;

  Item({required this.weight, required this.value, required this.name});
}

int max(int a, int b) => (a > b) ? a : b;