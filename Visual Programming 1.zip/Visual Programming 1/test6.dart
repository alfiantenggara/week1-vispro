import 'dart:io';

void main() {
  print('Masukkan jumlah jam kerja per minggu:');
  String? inputJam = stdin.readLineSync();
  if (inputJam != null && inputJam.isNotEmpty) {
    int jamKerja = int.tryParse(inputJam) ?? 0;
    int gajiTotal = hitungGaji(jamKerja);
    print('Gaji total untuk $jamKerja jam kerja per minggu adalah Rp $gajiTotal');
  } else {
    print('Input tidak valid');
  }
}

int hitungGaji(int jamKerja) {
  int gajiPokok = 4000000;
  int bonus = (jamKerja > 40) ? 200000 : 0;
  return gajiPokok + bonus;
}